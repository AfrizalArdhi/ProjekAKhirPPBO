/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

/**
 *
 * @author afriz
 */
public class DataKandang {
    private int id_kandang;
    private String nama_kandang;

    public int getId_kandang() {
        return id_kandang;
    }

    public void setId_kandang(int id_kandang) {
        this.id_kandang = id_kandang;
    }

    public String getNama_kandang() {
        return nama_kandang;
    }

    public void setNama_kandang(String nama_kandang) {
        this.nama_kandang = nama_kandang;
    }
    
    
}
