/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Views;
/**
 *
 * @author afriz
 */
public class ZooNextLevel {
    public static void main(String[] args) {
        // TODO code application logic here
        LoginPage n = new LoginPage();
        n.setVisible(true);
        n.setLocationRelativeTo(null);
    }
    
}
