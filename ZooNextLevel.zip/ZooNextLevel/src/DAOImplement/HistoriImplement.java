/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOImplement;
import Data.DataHistori;
import java.util.List;

/**
 *
 * @author afriz
 */
public interface HistoriImplement {
    public List<DataHistori> getAll();
}
