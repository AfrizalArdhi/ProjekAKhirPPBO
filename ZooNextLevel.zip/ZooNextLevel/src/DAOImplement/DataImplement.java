/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOImplement;
import Data.DataHewan;
import java.util.List;

public interface DataImplement {
    public List<DataHewan> getAll(String s);
}

